# WordPress App — AppForge Multi-Platform Build
Generated: 2026-03-11 16:18:36
Website:   https://wordpress.com
Package:   com.wordpress.mobileapp
Version:   2.0.0

## Files Included
  ✓ [Android APK] WordPress_App.apk (3 KB)
  ✓ [Android Studio Project] WordPress_App_AndroidStudio_Project.zip (6 KB)
  ✓ [Windows Electron Project] WordPress_App_Windows_Electron_Project.zip (4 KB)
  ✓ [iOS Xcode Project] WordPress_App_iOS_Xcode_Project.zip (5 KB)
  ✓ [Linux Project] WordPress_App_Linux_Project.zip (3 KB)

## Quick Start Guide

### Android (.apk)
1. Copy WordPress_App.apk to your Android phone
2. Settings > Security > Install Unknown Apps > Allow
3. Open file manager, tap the APK, tap Install
4. OR: Open Android Studio project for a production build

### Windows (.exe)
1. Open WordPress_App_Windows_Electron_Project.zip
2. npm install && npm run build-win
3. Run dist/WordPress App Setup.exe

### iOS (.ipa)
1. Open WordPress_App_iOS_Xcode_Project.zip
2. Open in Xcode on macOS
3. Build & run in simulator or export .ipa

### Linux (.AppImage)
1. Open WordPress_App_Linux_Project.zip
2. npm install && npm run build-linux
3. chmod +x *.AppImage && ./*.AppImage

## Built with AppForge — Free Multi-Platform App Builder
https://appforge.app
