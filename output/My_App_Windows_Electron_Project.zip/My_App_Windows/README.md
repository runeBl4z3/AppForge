# My App — Windows App
Built with AppForge on 2026-03-11 18:30:47

## Website
https://yourwebsite.com

## Run Locally (requires Node.js)
    npm install
    npm start

## Build Windows Installer (.exe)
    npm install
    npm run build-win
    # Output: dist/My App Setup.exe

## Build Linux (.AppImage)
    npm run build-linux
    # Output: dist/My App.AppImage

## Build macOS (.dmg)
    npm run build-mac
    # Output: dist/My App.dmg

## Requirements
- Node.js 18+ from https://nodejs.org
- npm (included with Node.js)
