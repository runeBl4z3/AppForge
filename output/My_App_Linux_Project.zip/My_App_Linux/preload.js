const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('appForge', {
    platform: process.platform,
    version: process.versions.electron,
    send: (channel, data) => ipcRenderer.send(channel, data),
    receive: (channel, func) => ipcRenderer.on(channel, (event, ...args) => func(...args))
});
