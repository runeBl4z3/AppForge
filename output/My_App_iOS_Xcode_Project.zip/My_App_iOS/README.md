# My App — iOS App
Built with AppForge on 2026-03-11 18:30:47

## Website
https://yourwebsite.com

## Requirements
- macOS with Xcode 15+
- Apple Developer Account (for device/App Store builds)
- CocoaPods (optional): https://cocoapods.org

## Open in Xcode
1. Install Xcode from Mac App Store
2. Open `My App.xcodeproj` in Xcode
3. Select your Team in Signing & Capabilities
4. Click Run (⌘R) to build and run in simulator

## Build for TestFlight / App Store
1. Select "Any iOS Device" as build target
2. Product > Archive
3. Upload via Xcode Organizer to App Store Connect

## Build .ipa (Ad Hoc)
1. Product > Archive
2. Distribute App > Ad Hoc
3. Export .ipa file
