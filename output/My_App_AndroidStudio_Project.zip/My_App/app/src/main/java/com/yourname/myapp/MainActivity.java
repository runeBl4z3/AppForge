package com.yourname.myapp;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.*;
import android.widget.*;

public class MainActivity extends Activity {

    private WebView webView;
    private ProgressBar progressBar;
    private LinearLayout offlineLayout;
    private static final String URL = "https://yourwebsite.com";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                             WindowManager.LayoutParams.FLAG_FULLSCREEN);
        buildUI();
        configureWebView();
        if (isOnline()) loadSite(); else showOffline();
    }

    private void buildUI() {
        RelativeLayout root = new RelativeLayout(this);
        root.setBackgroundColor(Color.parseColor("#08090c"));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        RelativeLayout.LayoutParams pbp = new RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.MATCH_PARENT, 8);
        pbp.addRule(RelativeLayout.ALIGN_PARENT_TOP);
        progressBar.setLayoutParams(pbp);
        progressBar.setId(1001);

        webView = new WebView(this);
        RelativeLayout.LayoutParams wvp = new RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT);
        wvp.addRule(RelativeLayout.BELOW, 1001);
        webView.setLayoutParams(wvp);
        webView.setId(1002);

        offlineLayout = new LinearLayout(this);
        offlineLayout.setOrientation(LinearLayout.VERTICAL);
        offlineLayout.setGravity(Gravity.CENTER);
        offlineLayout.setBackgroundColor(Color.parseColor("#08090c"));
        offlineLayout.setVisibility(View.GONE);
        RelativeLayout.LayoutParams olp = new RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT);
        offlineLayout.setLayoutParams(olp);

        TextView icon = new TextView(this); icon.setText("\uD83D\uDCF6");
        icon.setTextSize(64); icon.setGravity(Gravity.CENTER);
        TextView msg = new TextView(this); msg.setText("No Internet Connection");
        msg.setTextColor(Color.parseColor("#f1f2f6")); msg.setTextSize(20);
        msg.setGravity(Gravity.CENTER); msg.setPadding(0,16,0,8);
        TextView sub = new TextView(this); sub.setText("Check your network and try again.");
        sub.setTextColor(Color.parseColor("#6b7280")); sub.setTextSize(14);
        sub.setGravity(Gravity.CENTER); sub.setPadding(48,0,48,32);
        Button retry = new Button(this); retry.setText("Retry");
        retry.setBackgroundColor(Color.parseColor("#5b6ef5"));
        retry.setTextColor(Color.WHITE); retry.setPadding(60,20,60,20);
        retry.setOnClickListener(v -> { if (isOnline()) { offlineLayout.setVisibility(View.GONE);
            webView.setVisibility(View.VISIBLE); loadSite(); } });

        offlineLayout.addView(icon); offlineLayout.addView(msg);
        offlineLayout.addView(sub); offlineLayout.addView(retry);
        root.addView(progressBar); root.addView(webView); root.addView(offlineLayout);
        setContentView(root);
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true); s.setAllowFileAccess(true);
        s.setLoadWithOverviewMode(true); s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setGeolocationEnabled(true);
        s.setUserAgentString(s.getUserAgentString() + " AppForge/My_App/1.0");
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebChromeClient(new WebChromeClient() {
            public void onProgressChanged(WebView v, int p) {
                progressBar.setProgress(p);
                progressBar.setVisibility(p < 100 ? View.VISIBLE : View.GONE);
            }
            public void onGeolocationPermissionsShowPrompt(String o, GeolocationPermissions.Callback c) {
                c.invoke(o, true, false);
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (u.startsWith("http")) { v.loadUrl(u); return true; }
                return false;
            }
            public void onReceivedError(WebView v, WebResourceError e, WebResourceRequest r) {
                if (r.isForMainFrame()) showOffline();
            }
        });
    }

    private void loadSite() { webView.loadUrl(URL); }
    private void showOffline() {
        webView.setVisibility(View.GONE); offlineLayout.setVisibility(View.VISIBLE);
    }
    private boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        NetworkInfo ni = cm.getActiveNetworkInfo();
        return ni != null && ni.isConnectedOrConnecting();
    }
    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    @Override protected void onPause() { super.onPause(); webView.onPause(); }
    @Override protected void onResume() { super.onResume(); webView.onResume(); }
}
