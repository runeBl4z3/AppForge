# My App Android Project
Open in Android Studio to build.
URL: https://yourwebsite.com
